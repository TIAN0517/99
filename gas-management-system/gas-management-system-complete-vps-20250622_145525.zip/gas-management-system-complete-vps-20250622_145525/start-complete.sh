#!/bin/bash
# 瓦斯行管理系统完整启动脚本
echo "🚀 瓦斯行管理系统启动..."

# 设置环境变量
export NODE_ENV=production
export DISPLAY=:99
export APP_HOST=0.0.0.0
export APP_PORT=3000

# 启动虚拟显示
if ! pgrep -f "Xvfb :99" > /dev/null; then
    echo "启动虚拟显示..."
    Xvfb :99 -screen 0 1024x768x24 > /dev/null 2>&1 &
    sleep 2
fi

# 检查Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js 未安装，请先安装 Node.js"
    exit 1
fi

# 安装依赖
if [ ! -d "node_modules" ]; then
    echo "📦 安装依赖..."
    npm install --production
fi

# 构建应用（如果需要）
if [ ! -d "dist" ]; then
    echo "🔨 构建应用..."
    npm run build:linux
fi

# 启动应用
echo "✅ 启动瓦斯行管理系统..."
npm start
