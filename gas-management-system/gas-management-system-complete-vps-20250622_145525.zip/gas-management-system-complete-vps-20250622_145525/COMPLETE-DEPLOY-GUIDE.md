# 瓦斯行管理系统 - 完整VPS部署包
Jy技術團隊 2025

## 🚀 一键完整部署

### 方法一：超级快速部署 (推荐)
```bash
# 1. 解压部署包
unzip gas-management-system-complete-vps-*.zip
cd gas-management-system-complete-vps-*

# 2. 一键部署（包含应用和外网配置）
chmod +x *.sh && sudo ./deploy-external-access.sh
```

### 方法二：分步部署
```bash
# 1. 设置权限
chmod +x *.sh

# 2. 安装依赖和构建应用
sudo ./deploy-vps-linux.sh

# 3. 配置外网访问
sudo ./configure-external-access.sh

# 4. 可选：配置SSL证书
sudo ./setup-ssl-certificate.sh
```

## 📋 包含内容

本部署包包含：
- ✅ 完整的React/TypeScript源代码
- ✅ 所有页面组件 (ProductManagement.tsx等)
- ✅ 外网连线配置工具
- ✅ VPS优化脚本
- ✅ AI配置工具
- ✅ 完整文档

## 🌐 部署后访问

- **外网访问**: http://YOUR_SERVER_IP:3000
- **默认账号**: admin / password

## 💡 重要提醒

1. **云服务商安全组**: 必须开放端口 3000
2. **更改密码**: 首次登录后立即更改
3. **SSL配置**: 推荐配置HTTPS安全访问

## 🔧 故障排除

如遇问题：
```bash
sudo ./troubleshoot-external-access.sh
```

## 📞 技术支持

Jy技術團隊 2025  
Email: support@jytech.com
