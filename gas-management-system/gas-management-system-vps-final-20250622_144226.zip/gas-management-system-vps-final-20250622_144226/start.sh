#!/bin/bash
# 瓦斯行管理系统启动脚本
echo "🚀 启动瓦斯行管理系统..."

# 设置环境变量
export NODE_ENV=production
export DISPLAY=:99

# 启动虚拟显示
if ! pgrep -f "Xvfb :99" > /dev/null; then
    echo "启动虚拟显示..."
    Xvfb :99 -screen 0 1024x768x24 > /dev/null 2>&1 &
    sleep 2
fi

# 安装依赖
if [ ! -d "node_modules" ]; then
    echo "安装依赖..."
    npm install --production
fi

# 启动应用
echo "启动应用..."
npm start
