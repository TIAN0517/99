#!/bin/bash
# 设置所有脚本执行权限
echo "设置脚本执行权限..."
chmod +x *.sh
echo "✅ 权限设置完成"
echo "现在可以运行: sudo ./deploy-external-access.sh"
