# 瓦斯行管理系统 - VPS部署包
Jy技術團隊 2025

## 🚀 快速部署

### 方法一：一键自动部署 (推荐)
```bash
# 1. 解压部署包
unzip gas-management-system-vps-final-*.zip
cd gas-management-system-vps-final-*

# 2. 设置权限并一键部署
chmod +x *.sh && sudo ./deploy-external-access.sh
```

### 方法二：使用管理中心
```bash
# 1. 设置权限
chmod +x *.sh

# 2. 启动管理中心
sudo ./external-access-manager.sh
```

### 方法三：传统部署
```bash
# 1. 基础部署
chmod +x deploy-vps-linux.sh
sudo ./deploy-vps-linux.sh

# 2. 配置外网访问
sudo ./configure-external-access.sh
```

## 📋 部署后步骤

1. **配置云服务商安全组**
   - 开放端口 3000 (必需)
   - 开放端口 80, 443 (SSL可选)

2. **访问系统**
   - 外网访问: http://YOUR_SERVER_IP:3000
   - 默认账号: admin / password

3. **配置SSL证书** (可选)
   ```bash
   sudo ./setup-ssl-certificate.sh
   ```

## 🔧 故障排除

如遇问题，运行诊断工具：
```bash
sudo ./troubleshoot-external-access.sh
```

## 📞 技术支持

Jy技術團隊 2025
Email: support@jytech.com

## 📖 详细文档

查看以下文档获取更多信息：
- EXTERNAL-ACCESS-USAGE-GUIDE.md - 完整使用指南
- LINUX-VPS-DEPLOYMENT.md - Linux VPS 部署详解
- VPS-DEPLOYMENT-GUIDE.md - VPS 部署指南
