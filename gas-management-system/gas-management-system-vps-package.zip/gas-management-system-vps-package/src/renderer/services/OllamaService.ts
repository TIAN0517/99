// Ollama API 服務集成
export class OllamaService {
  private baseUrl: string = 'http://localhost:11434';
  private model: string = 'deepseek-r1:8b';

  constructor(baseUrl?: string, model?: string) {
    if (baseUrl) this.baseUrl = baseUrl;
    if (model) this.model = model;
  }

  /**
   * 檢查 Ollama 服務是否可用
   */
  async isAvailable(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`);
      return response.ok;
    } catch (error) {
      console.error('Ollama service not available:', error);
      return false;
    }
  }

  /**
   * 發送聊天消息到 Ollama
   */
  async chat(message: string, context?: string): Promise<{ message: string; error?: string }> {
    try {
      // 檢查服務是否可用
      const available = await this.isAvailable();
      if (!available) {
        return {
          message: '抱歉，AI 助理服務暫時無法使用。請確認 Ollama 服務是否正在運行。',
          error: 'Service unavailable'
        };
      }

      // 構建提示詞
      const prompt = this.buildPrompt(message, context);

      const response = await fetch(`${this.baseUrl}/api/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: this.model,
          prompt: prompt,
          stream: false,
          options: {
            temperature: 0.7,
            top_p: 0.9,
            max_tokens: 500,
          }
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      return {
        message: data.response || '抱歉，我無法處理您的請求。',
      };

    } catch (error) {
      console.error('Ollama chat error:', error);
      return {
        message: '抱歉，處理您的請求時發生錯誤。請稍後再試。',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * 構建針對瓦斯行業務的提示詞
   */
  private buildPrompt(message: string, context?: string): string {
    const systemPrompt = `你是"董娘的助理"，一個專門為瓦斯行業務設計的AI助手。你具備以下專業知識：

業務範圍：
- 液化石油氣(LPG)銷售與配送
- 瓦斯設備安裝與維護
- 客戶服務與訂單管理
- 庫存管理與成本控制
- 安全規範與法規遵循

回答風格：
- 使用繁體中文
- 語氣親切專業
- 提供實用的建議
- 關注安全與效率

請根據用戶的問題提供專業且實用的回答。

${context ? `業務背景：${context}` : ''}

用戶問題：${message}

董娘的助理回覆：`;

    return systemPrompt;
  }

  /**
   * 獲取可用的模型列表
   */
  async getAvailableModels(): Promise<string[]> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`);
      if (!response.ok) return [];
      
      const data = await response.json();
      return data.models?.map((model: any) => model.name) || [];
    } catch (error) {
      console.error('Failed to get models:', error);
      return [];
    }
  }

  /**
   * 設置使用的模型
   */
  setModel(model: string): void {
    this.model = model;
  }

  /**
   * 獲取當前使用的模型
   */
  getCurrentModel(): string {
    return this.model;
  }
}

// 創建單例實例
export const ollamaService = new OllamaService();

// 業務相關的快速回復模板
export const quickResponses = {
  greeting: '您好！我是董娘的助理，很高興為您服務！我可以幫您處理訂單查詢、庫存管理、客戶服務等各種業務問題。請告訴我您需要什麼幫助？',
  
  orderStatus: '讓我為您查詢訂單狀態。請提供訂單編號，我會立即為您確認配送進度和預計到達時間。',
  
  inventory: '關於庫存查詢，我可以幫您：\n• 檢查各規格瓦斯的庫存數量\n• 預警低庫存商品\n• 建議補貨時機\n• 分析銷售趨勢',
  
  safety: '瓦斯安全非常重要！請記住：\n• 定期檢查瓦斯管線\n• 使用合格的瓦斯器具\n• 保持通風良好\n• 發現異味立即關閉瓦斯\n• 定期更換老化設備',
  
  pricing: '關於價格資訊，我可以提供：\n• 各規格瓦斯的最新價格\n• 大量採購的優惠方案\n• 季節性價格調整資訊\n• 競爭對手價格分析',
};
