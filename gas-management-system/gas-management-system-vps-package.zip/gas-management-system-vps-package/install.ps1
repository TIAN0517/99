# Jy技術團隊 - 瓦斯行管理系統 2025 安装脚本

Write-Host "🚀 安装 Jy技術團隊 - 瓦斯行管理系統 2025..." -ForegroundColor Green

# 检查 Node.js
try {
    $nodeVersion = node --version
    Write-Host "✅ Node.js 版本: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ 请先安装 Node.js (https://nodejs.org/)" -ForegroundColor Red
    exit 1
}

# 安装依赖
Write-Host "📦 安装依赖包..." -ForegroundColor Blue
npm install

# 构建应用
Write-Host "🔨 构建应用..." -ForegroundColor Blue
npm run build

Write-Host "✅ 安装完成！" -ForegroundColor Green
Write-Host "🚀 使用 'npm start' 启动应用" -ForegroundColor Yellow
Write-Host "🌐 Powered by Jy技術團隊 © 2025" -ForegroundColor Cyan
