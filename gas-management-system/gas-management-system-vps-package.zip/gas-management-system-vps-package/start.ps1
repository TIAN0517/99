# Jy技術團隊 - 瓦斯行管理系統 2025 启动脚本

Write-Host "🚀 启动 Jy技術團隊 - 瓦斯行管理系統 2025..." -ForegroundColor Green

# 检查是否已构建
if (-not (Test-Path "dist")) {
    Write-Host "⚠️  未找到构建文件，正在构建..." -ForegroundColor Yellow
    npm run build
}

# 启动应用
npm start
