# VPS 部署指南 - Jy技術團隊 瓦斯行管理系統 2025

## 系统要求
- Node.js 18+ 
- npm 或 yarn
- 至少 2GB RAM
- Windows Server 2016+ 或 Ubuntu 18.04+

## 安装步骤

### Windows VPS
1. 解压缩文件到目标目录
2. 以管理员身份运行 PowerShell
3. 执行: Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
4. 执行: .\install.ps1
5. 执行: .\start.ps1

### Linux VPS
`ash
# 解压缩文件
unzip gas-management-system-vps-package.zip
cd gas-management-system-vps-package

# 安装依赖
npm install

# 构建应用
npm run build

# 启动应用
npm start
`

## AI 助理设置（可选）
如果要使用 AI 助理功能，请安装 Ollama：

### Windows
`ash
winget install Ollama.Ollama
ollama pull deepseek-r1:8b
ollama serve
`

### Linux
`ash
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull deepseek-r1:8b
ollama serve
`

## 端口配置
- 应用端口：默认 Electron 桌面应用
- Ollama API：http://localhost:11434

## 故障排除
1. 权限问题：确保有足够的文件读写权限
2. 端口占用：检查 11434 端口是否被占用
3. 内存不足：确保至少有 2GB 可用内存

## 技术支持
- 开发者：Jy技術團隊
- 版本：1.0.0 (2025)
- 联系：contact@jytech.com
