#!/bin/bash

echo "🚀 Jy技術團隊 瓦斯行管理系統 2025 - 快速启动"
echo "=============================================="

# 设置错误处理
set -e

# 检查 Docker 服务
if ! systemctl is-active --quiet docker; then
    echo "🐳 启动 Docker 服务..."
    systemctl start docker
    sleep 3
fi

# 检查 Ollama 容器
if ! docker ps --format '{{.Names}}' | grep -q "^ollama$"; then
    echo "🤖 启动 Ollama 容器..."
    if docker ps -a --format '{{.Names}}' | grep -q "^ollama$"; then
        docker start ollama
    else
        echo "❌ Ollama 容器不存在，请先运行完整部署脚本"
        exit 1
    fi
    sleep 10
fi

# 等待 Ollama API 就绪
echo "⏳ 等待 Ollama API 就绪..."
timeout=30
while [  -gt 0 ]; do
    if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
        echo "✅ Ollama API 就绪"
        break
    fi
    echo "等待中... ()"
    sleep 1
    ((timeout--))
done

if [  -eq 0 ]; then
    echo "❌ Ollama API 启动超时，尝试重启容器..."
    docker restart ollama
    sleep 15
fi

# 设置虚拟显示
export DISPLAY=:99
if ! pgrep -f "Xvfb :99" > /dev/null; then
    echo "🖥️ 启动虚拟显示..."
    Xvfb :99 -screen 0 1024x768x24 > /dev/null 2>&1 &
    sleep 2
fi

# 进入应用目录
cd /opt/gas-management-system

# 启动应用
echo "🚀 启动瓦斯行管理系統..."
if command -v pm2 &> /dev/null; then
    echo "使用 PM2 启动..."
    pm2 start ecosystem.config.js
    pm2 logs gas-management-system
else
    echo "直接启动..."
    npm start
fi
