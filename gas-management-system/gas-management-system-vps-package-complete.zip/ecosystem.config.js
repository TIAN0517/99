module.exports = {
  apps: [{
    name: 'gas-management-system',
    script: 'dist/main/main.js',
    cwd: '/opt/gas-management-system',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '400M',
    env: {
      NODE_ENV: 'production',
      DISPLAY: ':99',
      OLLAMA_BASE_URL: 'http://localhost:11434'
    },
    log_file: './logs/app.log',
    out_file: './logs/out.log', 
    error_file: './logs/error.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    merge_logs: true,
    kill_timeout: 3000
  }]
};
