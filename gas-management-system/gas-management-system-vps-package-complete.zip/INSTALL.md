# Jy技術團隊 瓦斯行管理系統 2025 - VPS 安装说明

## 🚀 快速开始

### 1. 一键部署（推荐）
`ash
chmod +x deploy-vps-complete.sh
./deploy-vps-complete.sh
`

### 2. 手动部署
请参考 VPS-DEPLOYMENT-GUIDE.md 获取详细说明。

## 📊 系统要求

- **最低配置**: 2GB RAM, 10GB 存储空间
- **推荐配置**: 4GB RAM, 20GB 存储空间  
- **操作系统**: Ubuntu 20.04+, CentOS 8+, Debian 11+

## 🔧 管理命令

`ash
# 启动应用
./quick-start.sh

# 停止应用
./stop.sh

# 查看状态
./monitor.sh

# 系统服务管理
systemctl start|stop|restart gas-management
`

## 📞 技术支持

- **开发团队**: Jy技術團隊
- **版本**: 2025
- **文档**: VPS-DEPLOYMENT-GUIDE.md

---
© 2025 Jy技術團隊. All rights reserved.
