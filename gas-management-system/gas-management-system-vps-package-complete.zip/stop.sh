#!/bin/bash

echo "🛑 停止 Jy技術團隊 瓦斯行管理系統 2025"

# 停止 PM2 应用
if command -v pm2 &> /dev/null; then
    pm2 stop gas-management-system
    pm2 delete gas-management-system
fi

# 停止系统服务
systemctl stop gas-management || true

# 停止进程
pkill -f "node.*main.js" || true
pkill -f "Xvfb :99" || true

echo "✅ 应用已停止"
