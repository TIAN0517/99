#!/bin/bash
echo "🚀 UltraModern4D瓦斯管理系统启动中..."
echo "====================================="

echo "📋 检查Node.js环境..."
if ! command -v node &> /dev/null; then
    echo "❌ Node.js未安装，请先安装Node.js 16+"
    exit 1
fi

echo "✅ Node.js环境正常"

echo "📦 安装依赖包..."
npm install

echo "🔧 编译系统..."
npm run build

echo "🚀 启动UltraModern4D系统..."
npm start
