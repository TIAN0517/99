import React, { useState, useEffect } from 'react';
import { LoginPage } from './pages/LoginPage';
import UltraModern4D from './pages/UltraModern4D';
import { TitleBar } from './components/TitleBar';
import { Sidebar } from './components/Sidebar';
import { ProductManagement } from './pages/ProductManagement';
import { OrderManagement } from './pages/OrderManagement';
import { CustomerManagement } from './pages/CustomerManagement';
import { FinancialAnalysis } from './pages/FinancialAnalysis';
import { AIAssistant } from './components/AIAssistant';
import { User } from '../types';
import './styles/App-4d.css';

export const App: React.FC = () => {
    // 直接显示UltraModern4D系统，因为它已经包含了完整的功能
    return <UltraModern4D />;
};
